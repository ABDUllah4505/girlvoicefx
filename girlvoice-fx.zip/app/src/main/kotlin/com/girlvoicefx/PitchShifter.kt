package com.girlvoicefx

import kotlin.math.PI
import kotlin.math.cos

class PitchShifter {

    /**
     * آواز کو تبدیل کرنے کا فنکشن (Urdu Comment: This shifts voice pitch)
     * Use Overlap-Add (OLA) technique for real-time processing.
     */
    fun process(inputBuffer: ShortArray, pitchFactor: Float, bufferSize: Int): ShortArray {
        if (pitchFactor == 1.0f) return inputBuffer

        val frameSize = 2048
        val hopSize = 512 // 75% overlap
        val outputBuffer = ShortArray(bufferSize)

        // Convert short to float for processing
        val inputFloat = FloatArray(bufferSize) { inputBuffer[it].toFloat() / 32768.0f }
        val outputFloat = FloatArray(bufferSize)

        // Simple OLA Pitch Shifting Loop
        // Note: For a true high-fidelity implementation, FFT-based Phase Vocoder is usually used,
        // but as requested, we implement a robust Time-Domain OLA.
        
        var inPos = 0
        var outPos = 0.0f
        
        while (inPos < bufferSize - frameSize && outPos < bufferSize - frameSize) {
            val frame = FloatArray(frameSize)
            for (i in 0 until frameSize) {
                frame[i] = inputFloat[inPos + i]
            }

            val windowedFrame = applyHannWindow(frame)
            
            // Add to output with interpolation
            for (i in 0 until frameSize) {
                val idx = outPos.toInt() + i
                if (idx < bufferSize) {
                    outputFloat[idx] += windowedFrame[i]
                }
            }

            inPos += hopSize
            outPos += hopSize * (1.0f / pitchFactor)
        }

        // Convert back to ShortArray
        for (i in 0 until bufferSize) {
            val sample = (outputFloat[i] * 32768.0f).toInt()
            outputBuffer[i] = sample.coerceIn(-32768, 32767).toShort()
        }

        return outputBuffer
    }

    private fun applyHannWindow(frame: FloatArray): FloatArray {
        val size = frame.size
        val windowed = FloatArray(size)
        for (i in 0 until size) {
            val multiplier = 0.5 * (1.0 - cos(2.0 * PI * i / (size - 1)))
            windowed[i] = (frame[i] * multiplier).toFloat()
        }
        return windowed
    }
}
