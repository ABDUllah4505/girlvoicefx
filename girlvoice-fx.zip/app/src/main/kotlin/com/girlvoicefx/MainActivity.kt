package com.girlvoicefx

/*
 * HOW TO USE GIRLVOICE FX IN GAMES:
 *
 * DISCORD:
 * 1. Open this app → Select girl voice → Tap MIC ON
 * 2. Open Discord → User Settings → Voice & Video
 * 3. Set Input Device to: "GirlVoice FX" or "Virtual Mic"
 * 4. Join voice channel — opponents hear girl voice!
 *
 * PUBG MOBILE / FREE FIRE:
 * 1. Start GirlVoice FX first, keep it running in background
 * 2. Open game → Settings → Audio → Microphone
 * 3. If virtual mic option appears, select it
 * 4. Otherwise: use Discord overlay while gaming
 *
 * NOTE: On non-rooted Android, some games may not allow
 * third-party mic input. In that case, use Discord voice
 * chat alongside the game for best results.
 */

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.IBinder
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.girlvoicefx.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var voiceService: VoiceChangerService? = null
    private var isBound = false
    private var isMicOn = false

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            toggleMic()
        } else {
            Toast.makeText(this, "Permission denied. Audio cannot be captured.", Toast.LENGTH_SHORT).show()
        }
    }

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(className: ComponentName, service: IBinder) {
            val binder = service as VoiceChangerService.LocalBinder
            voiceService = binder.getService()
            isBound = true
        }

        override fun onServiceDisconnected(arg0: ComponentName) {
            isBound = false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupUI()
        bindService()
    }

    private fun bindService() {
        val intent = Intent(this, VoiceChangerService::class.java)
        bindService(intent, connection, Context.BIND_AUTO_CREATE)
    }

    private fun setupUI() {
        binding.btnMic.setOnClickListener {
            checkPermissionAndToggle()
        }

        binding.sbPitch.apply {
            max = 200
            progress = (VOICE_PRESETS[0].pitchFactor * 100).toInt()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val factor = progress / 100f
                    binding.tvPitchValue.text = String.format("%.2f", factor)
                    // Update engine if needed
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }

        binding.swNoise.setOnCheckedChangeListener { _, isChecked ->
            voiceService?.setNoiseCancellation(isChecked)
        }
    }

    private fun checkPermissionAndToggle() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            toggleMic()
        } else {
            requestPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun toggleMic() {
        isMicOn = !isMicOn
        if (isMicOn) {
            binding.btnMic.text = "MIC ON"
            binding.btnMic.setBackgroundColor(0xFFE879B0.toInt())
            binding.tvStatusBadge.text = "LIVE"
            binding.visualizerView.startAnimating()
            
            val intent = Intent(this, VoiceChangerService::class.java)
            startForegroundService(intent)
        } else {
            binding.btnMic.text = "MIC OFF"
            binding.btnMic.setBackgroundColor(0xFFFF4444.toInt())
            binding.tvStatusBadge.text = "MUTED"
            binding.visualizerView.stopAnimating()
            
            stopService(Intent(this, VoiceChangerService::class.java))
        }
    }

    override fun onDestroy() {
        if (isBound) {
            unbindService(connection)
            isBound = false
        }
        super.onDestroy()
    }
}
