package com.girlvoicefx

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import kotlin.random.Random

class VisualizerView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val paint = Paint().apply {
        color = 0xFFE879B0.toInt()
        isAntiAlias = true
        style = Paint.Style.FILL
    }

    private val barWidth = 10f
    private val gap = 6f
    private val barCount = 32
    private var isAnimating = false
    private val heights = FloatArray(barCount)

    fun startAnimating() {
        isAnimating = true
        invalidate()
    }

    fun stopAnimating() {
        isAnimating = false
        for (i in 0 until barCount) heights[i] = 2f
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val totalWidth = (barWidth + gap) * barCount - gap
        val startX = (width - totalWidth) / 2

        for (i in 0 until barCount) {
            if (isAnimating) {
                heights[i] = Random.nextFloat() * (height * 0.8f) + 5f
            } else {
                heights[i] = 2f
            }

            val left = startX + i * (barWidth + gap)
            val top = height / 2f - heights[i] / 2f
            val right = left + barWidth
            val bottom = height / 2f + heights[i] / 2f

            canvas.drawRoundRect(left, top, right, bottom, 5f, 5f, paint)
        }

        if (isAnimating) {
            postInvalidateDelayed(100)
        }
    }
}
