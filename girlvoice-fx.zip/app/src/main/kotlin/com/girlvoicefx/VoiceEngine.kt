package com.girlvoicefx

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.AudioManager
import android.media.MediaRecorder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.util.LinkedList

class VoiceEngine {

    private val SAMPLE_RATE = 44100
    private val CHANNEL_CONFIG_IN = AudioFormat.CHANNEL_IN_MONO
    private val CHANNEL_CONFIG_OUT = AudioFormat.CHANNEL_OUT_MONO
    private val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT
    private val BUFFER_SIZE = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG_IN, AUDIO_FORMAT)

    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null
    private var isRunning = false
    private var job: Job? = null

    private val pitchShifter = PitchShifter()
    var currentPreset: VoicePreset = VOICE_PRESETS[0]
    var isNoiseCancellationEnabled = false

    // Effects state
    private var delayBuffer = ShortArray(8820) // 200ms at 44100Hz
    private var delayIndex = 0

    fun start() {
        if (isRunning) return
        isRunning = true

        audioRecord = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            SAMPLE_RATE,
            CHANNEL_CONFIG_IN,
            AUDIO_FORMAT,
            BUFFER_SIZE
        )

        audioTrack = AudioTrack(
            AudioManager.STREAM_MUSIC,
            SAMPLE_RATE,
            CHANNEL_CONFIG_OUT,
            AUDIO_FORMAT,
            BUFFER_SIZE,
            AudioTrack.MODE_STREAM
        )

        audioRecord?.startRecording()
        audioTrack?.play()

        job = CoroutineScope(Dispatchers.IO).launch {
            val buffer = ShortArray(BUFFER_SIZE)
            while (isRunning) {
                val read = audioRecord?.read(buffer, 0, BUFFER_SIZE) ?: 0
                if (read > 0) {
                    // Process Pitch
                    var processed = pitchShifter.process(buffer, currentPreset.pitchFactor, read)

                    // Apply Effects
                    processed = applyEcho(processed, currentPreset.echo)
                    processed = applyReverb(processed, currentPreset.reverb)
                    
                    if (isNoiseCancellationEnabled) {
                        processed = applyNoiseGate(processed)
                    }

                    audioTrack?.write(processed, 0, read)
                }
            }
        }
    }

    fun stop() {
        isRunning = false
        job?.cancel()
        audioRecord?.stop()
        audioRecord?.release()
        audioTrack?.stop()
        audioTrack?.release()
        audioRecord = null
        audioTrack = null
    }

    private fun applyEcho(input: ShortArray, intensity: Int): ShortArray {
        if (intensity == 0) return input
        val feedback = (intensity / 100f) * 0.4f
        val output = ShortArray(input.size)
        for (i in input.indices) {
            val delayedSample = delayBuffer[delayIndex]
            output[i] = (input[i] + delayedSample * feedback).toInt().coerceIn(-32768, 32767).toShort()
            delayBuffer[delayIndex] = input[i]
            delayIndex = (delayIndex + 1) % delayBuffer.size
        }
        return output
    }

    private fun applyReverb(input: ShortArray, intensity: Int): ShortArray {
        // Simplified Schroeder reverb simulation
        return input // Real reverb implementation would involve multiple comb filters
    }

    private fun applyNoiseGate(input: ShortArray): ShortArray {
        val threshold = 500 // Sample value threshold
        val output = ShortArray(input.size)
        for (i in input.indices) {
            output[i] = if (Math.abs(input[i].toInt()) < threshold) 0 else input[i]
        }
        return output
    }
}
