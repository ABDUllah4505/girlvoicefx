package com.girlvoicefx

data class VoicePreset(
    val name: String,
    val emoji: String,
    val tag: String,
    val pitchFactor: Float,
    val warmth: Int,
    val echo: Int,
    val reverb: Int
)

val VOICE_PRESETS = listOf(
    VoicePreset("Soft Girl",   "🌸", "SWEET · GENTLE",   1.35f, 20, 15, 30),
    VoicePreset("Anime Girl",  "✨", "HIGH · CUTE",       1.55f, 10, 25, 40),
    VoicePreset("Gamer Girl",  "🎮", "NATURAL · CLEAR",   1.25f, 15, 10, 20),
    VoicePreset("Elven",       "🧝", "MYSTIC · AIRY",     1.40f,  8, 35, 55),
    VoicePreset("Queen",       "👑", "BOLD · STRONG",     1.20f, 25, 20, 35),
    VoicePreset("Kawaii",      "🍭", "TINY · BUBBLY",     1.65f,  5, 30, 45)
)
