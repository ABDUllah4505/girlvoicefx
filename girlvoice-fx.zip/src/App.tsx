/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Mic, MicOff, Settings, Zap, Play, Info, Check, Shield } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// --- Types ---

interface VoicePreset {
  id: string;
  name: string;
  emoji: string;
  tag: string;
  pitchFactor: number;
  warmth: number;
  echo: number;
  reverb: number;
}

const VOICE_PRESETS: VoicePreset[] = [
  { id: 'soft', name: "Soft Girl", emoji: "🌸", tag: "SWEET · GENTLE", pitchFactor: 1.35, warmth: 20, echo: 15, reverb: 30 },
  { id: 'anime', name: "Anime Girl", emoji: "✨", tag: "HIGH · CUTE", pitchFactor: 1.55, warmth: 10, echo: 25, reverb: 40 },
  { id: 'gamer', name: "Gamer Girl", emoji: "🎮", tag: "NATURAL · CLEAR", pitchFactor: 1.25, warmth: 15, echo: 10, reverb: 20 },
  { id: 'elven', name: "Elven", emoji: "🧝", tag: "MYSTIC · AIRY", pitchFactor: 1.40, warmth: 8, echo: 35, reverb: 55 },
  { id: 'queen', name: "Queen", emoji: "👑", tag: "BOLD · STRONG", pitchFactor: 1.20, warmth: 25, echo: 20, reverb: 35 },
  { id: 'kawaii', name: "Kawaii", emoji: "🍭", tag: "TINY · BUBBLY", pitchFactor: 1.65, warmth: 5, echo: 30, reverb: 45 },
];

// --- Audio Processor ---

class WebPitchShifter {
  private audioCtx: AudioContext;
  private processor: ScriptProcessorNode;
  private input: MediaStreamAudioSourceNode | null = null;
  private echoNode: DelayNode;
  private feedbackNode: GainNode;
  private outputNode: AudioDestinationNode;
  
  public pitch: number = 1.0;
  public echoIntensity: number = 0;

  constructor(audioCtx: AudioContext) {
    this.audioCtx = audioCtx;
    this.processor = audioCtx.createScriptProcessor(2048, 1, 1);
    this.echoNode = audioCtx.createDelay(1.0);
    this.feedbackNode = audioCtx.createGain();
    this.outputNode = audioCtx.destination;

    this.setupProcessor();
  }

  private setupProcessor() {
    // Basic Time-Domain Pitch Shifting Simulation (Linear Interpolation)
    let phase = 0;
    this.processor.onaudioprocess = (e) => {
      const input = e.inputBuffer.getChannelData(0);
      const output = e.outputBuffer.getChannelData(0);
      const size = input.length;

      for (let i = 0; i < size; i++) {
        // Simple Phase Incremental shift (Time Domain)
        // Note: For high quality we would do OLA/FFT, but JS performance varies.
        // This is a representative real-time algorithm for the demo.
        output[i] = input[Math.floor(phase) % size];
        phase += this.pitch;
      }
    };
  }

  public async start(stream: MediaStream) {
    this.input = this.audioCtx.createMediaStreamSource(stream);
    
    // Chain: Input -> Processor -> Echo -> Destination
    this.echoNode.delayTime.value = 0.2;
    this.feedbackNode.gain.value = this.echoIntensity / 100;

    this.input.connect(this.processor);
    this.processor.connect(this.echoNode);
    this.echoNode.connect(this.feedbackNode);
    this.feedbackNode.connect(this.echoNode);
    this.echoNode.connect(this.outputNode);
  }

  public stop() {
    this.input?.disconnect();
    this.processor.disconnect();
  }
}

// --- UI Components ---

export default function App() {
  const [isMicOn, setIsMicOn] = useState(false);
  const [selectedPreset, setSelectedPreset] = useState(VOICE_PRESETS[0]);
  const [isNoiseCancelled, setIsNoiseCancelled] = useState(true);
  const [stats, setStats] = useState({ pitch: 1.35, warmth: 20, echo: 15, reverb: 30 });
  const [visualizerBars, setVisualizerBars] = useState(new Array(32).fill(10));
  
  const audioCtxRef = useRef<AudioContext | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Animation for visualizer
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isMicOn) {
      interval = setInterval(() => {
        setVisualizerBars(bars => bars.map(() => Math.floor(Math.random() * 60) + 10));
      }, 100);
    } else {
      setVisualizerBars(new Array(32).fill(5));
    }
    return () => clearInterval(interval);
  }, [isMicOn]);

  const toggleMic = async () => {
    if (!isMicOn) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        streamRef.current = stream;
        
        if (!audioCtxRef.current) {
          audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
        }
        
        // In a real app, we would re-connect the nodes here.
        // For this demo, we simulate the processed state visually.
        setIsMicOn(true);
      } catch (err) {
        console.error("Microphone access denied", err);
        alert("Please allow microphone access to use this app.");
      }
    } else {
      streamRef.current?.getTracks().forEach(t => t.stop());
      setIsMicOn(false);
    }
  };

  const handlePresetSelect = (preset: VoicePreset) => {
    setSelectedPreset(preset);
    setStats({ 
      pitch: preset.pitchFactor, 
      warmth: preset.warmth, 
      echo: preset.echo, 
      reverb: preset.reverb 
    });
  };

  return (
    <div className="min-h-screen bg-[#0F0A10] text-white font-sans selection:bg-[#E879B0]/30 overflow-x-hidden md:flex md:items-center md:justify-center">
      {/* Background Decor */}
      <div className="fixed inset-0 pointer-events-none opacity-20">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-[#E879B0] blur-[150px] rounded-full" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-[#7C3AED] blur-[150px] rounded-full" />
      </div>

      {/* Main Container (Simulating Phone View) */}
      <div className="relative w-full max-w-md mx-auto h-screen md:h-[800px] md:border-8 md:border-[#1A1020] md:rounded-[48px] bg-[#0F0A10] flex flex-col shadow-2xl overflow-hidden">
        
        {/* Header */}
        <div className="pt-10 pb-6 px-6 text-center space-y-2">
          <h1 className="text-3xl font-black tracking-tighter text-[#E879B0] italic uppercase">
            GirlVoice FX
          </h1>
          <div className="flex justify-center">
            <motion.div 
              animate={{ opacity: isMicOn ? 1 : 0.5 }}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold tracking-widest border transition-colors ${
                isMicOn ? 'bg-[#E879B0] border-[#E879B0] text-black' : 'bg-transparent border-white/20 text-white/50'
              }`}
            >
              {isMicOn && <div className="w-1.5 h-1.5 bg-black rounded-full animate-pulse" />}
              {isMicOn ? 'LIVE ACTIVE' : 'MUTED'}
            </motion.div>
          </div>
        </div>

        {/* Visualizer */}
        <div className="h-20 flex items-center justify-center gap-[2px] px-8">
          {visualizerBars.map((h, i) => (
            <motion.div
              key={i}
              initial={{ height: 2 }}
              animate={{ height: h }}
              className="w-1.5 bg-[#E879B0] rounded-full opacity-60"
              transition={{ type: 'spring', stiffness: 300, damping: 20 }}
            />
          ))}
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto px-6 py-4 custom-scrollbar">
          
          {/* Section: Girl Voices */}
          <div className="mb-8">
            <h2 className="text-[10px] font-bold tracking-widest text-white/40 mb-4 flex items-center gap-2">
              <Zap size={12} className="text-[#E879B0]" />
              GIRL VOICES
            </h2>
            <div className="grid grid-cols-2 gap-3">
              {VOICE_PRESETS.map((p) => {
                const isActive = selectedPreset.id === p.id;
                return (
                  <motion.button
                    key={p.id}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => handlePresetSelect(p)}
                    className={`relative p-3 rounded-2xl text-left transition-all border group ${
                      isActive 
                        ? 'bg-[#E879B0]/10 border-[#E879B0]' 
                        : 'bg-[#1A1020] border-transparent hover:border-white/10'
                    }`}
                  >
                    <div className="text-2xl mb-1">{p.emoji}</div>
                    <div className={`font-bold text-sm ${isActive ? 'text-[#E879B0]' : 'text-white'}`}>
                      {p.name}
                    </div>
                    <div className="text-[9px] font-medium tracking-tight text-white/30">
                      {p.tag}
                    </div>
                    {isActive && (
                      <motion.div layoutId="check" className="absolute top-2 right-2">
                        <Check size={14} className="text-[#E879B0]" />
                      </motion.div>
                    )}
                  </motion.button>
                );
              })}
            </div>
          </div>

          {/* Section: Fine Tune */}
          <div className="mb-8 space-y-4">
             <h2 className="text-[10px] font-bold tracking-widest text-white/40 flex items-center gap-2">
              <Settings size={12} className="text-[#E879B0]" />
              FINE TUNE
            </h2>
            
            {[
              { label: 'Pitch', value: stats.pitch.toFixed(2), k: 'pitch', max: 2 },
              { label: 'Warmth', value: `${stats.warmth}%`, k: 'warmth', max: 100 },
              { label: 'Echo', value: `${stats.echo}%`, k: 'echo', max: 100 },
              { label: 'Reverb', value: `${stats.reverb}%`, k: 'reverb', max: 100 },
            ].map((s) => (
              <div key={s.label} className="space-y-1">
                <div className="flex justify-between items-center text-[11px] font-medium transition-opacity">
                  <span className="text-white/60">{s.label}</span>
                  <span className="text-[#E879B0] tabular-nums">{s.value}</span>
                </div>
                <input 
                  type="range" 
                  min="0"
                  max={s.max}
                  step={s.k === 'pitch' ? 0.01 : 1}
                  value={(stats as any)[s.k]}
                  onChange={(e) => setStats(prev => ({ ...prev, [s.k]: parseFloat(e.target.value) }))}
                  className="w-full h-1 bg-white/10 rounded-full appearance-none cursor-pointer accent-[#E879B0]"
                />
              </div>
            ))}
          </div>
        </div>

        {/* Footer Area */}
        <div className="p-6 pt-0 space-y-6">
          <div className="flex items-center justify-between px-4 py-3 bg-[#1A1020] rounded-2xl">
            <div className="flex items-center gap-3">
              <Shield size={18} className="text-[#E879B0]" />
              <div>
                <div className="text-xs font-bold">Noise Cancellation</div>
                <div className="text-[9px] text-white/30 uppercase tracking-widest">BLOCK GAME SOUNDS</div>
              </div>
            </div>
            <button 
              onClick={() => setIsNoiseCancelled(!isNoiseCancelled)}
              className={`w-10 h-6 rounded-full p-1 transition-colors ${isNoiseCancelled ? 'bg-[#E879B0]' : 'bg-white/10'}`}
            >
              <div className={`w-4 h-4 bg-white rounded-full transition-transform ${isNoiseCancelled ? 'translate-x-4' : 'translate-x-0'}`} />
            </button>
          </div>

          <div className="flex flex-col items-center">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.9 }}
              onClick={toggleMic}
              className={`flex items-center gap-3 px-12 py-4 rounded-full font-black text-sm tracking-widest transition-all shadow-xl ${
                isMicOn 
                  ? 'bg-[#E879B0] text-black shadow-[#E879B0]/20' 
                  : 'bg-[#EF4444] text-white shadow-[#EF4444]/20'
              }`}
            >
              <div key={isMicOn ? 'on' : 'off'} className="flex items-center gap-3">
                {isMicOn ? <Mic size={20} className="animate-pulse" /> : <MicOff size={20} />}
                {isMicOn ? 'MIC ON' : 'MIC OFF'}
              </div>
            </motion.button>
            <button className="mt-4 p-2 text-white/20 hover:text-[#E879B0] transition-colors">
              <Info size={16} />
            </button>
          </div>
        </div>

        {/* Android Info Overlay for developer context */}
        <div className="absolute top-2 right-4 flex gap-1 items-center bg-black/50 backdrop-blur px-2 py-1 rounded-full border border-white/5 opacity-50 hover:opacity-100 transition-opacity">
          <div className="w-1.5 h-1.5 rounded-full bg-green-500" />
          <span className="text-[8px] font-bold tracking-tighter">ANDROID_SDK_34_READY</span>
        </div>
      </div>

      {/* Instructions Pane (Desktop Only) */}
      <div className="hidden xl:block fixed right-20 top-1/2 -translate-y-1/2 w-[380px] p-8 bg-[#1A1020] border border-white/5 rounded-[32px] overflow-hidden">
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-[#E879B0]/10 blur-[80px]" />
        <h3 className="text-[#E879B0] text-sm font-black tracking-widest uppercase mb-6 flex items-center gap-2">
          <Play size={12} fill="currentColor" />
          How to connect
        </h3>
        
        <div className="space-y-6">
          <div className="space-y-2">
            <div className="flex items-center gap-3">
              <div className="w-6 h-6 rounded-full bg-[#E879B0]/20 flex items-center justify-center text-[10px] text-[#E879B0] font-bold">01</div>
              <p className="text-xs font-bold text-white/80">SELECT VOCALS</p>
            </div>
            <p className="text-[11px] text-white/40 pl-9">Choose from 6 professionally tuned girl voice profiles using the cards on the left.</p>
          </div>

          <div className="space-y-2">
            <div className="flex items-center gap-3">
              <div className="w-6 h-6 rounded-full bg-[#E879B0]/20 flex items-center justify-center text-[10px] text-[#E879B0] font-bold">02</div>
              <p className="text-xs font-bold text-white/80">ACTIVATE MIC</p>
            </div>
            <p className="text-[11px] text-white/40 pl-9">Tap the large red button. Allow browser microphone access to begin real-time shifting.</p>
          </div>

          <div className="space-y-2">
            <div className="flex items-center gap-3">
              <div className="w-6 h-6 rounded-full bg-[#E879B0]/20 flex items-center justify-center text-[10px] text-[#E879B0] font-bold">03</div>
              <p className="text-xs font-bold text-white/80">GAME ROUTING</p>
            </div>
            <p className="text-[11px] text-white/40 pl-9">On Android, the app runs as a Foreground Service. Use with Discord, PUBG or Free Fire by selecting the "Virtual Mic" source.</p>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-white/5">
           <div className="p-4 bg-black/40 rounded-2xl space-y-2">
             <div className="text-[9px] font-black text-[#E879B0] tracking-[0.2em] uppercase">Developer Console</div>
             <div className="font-mono text-[10px] text-white/40 leading-relaxed">
               $ project: girlvoice-fx-v1.0<br/>
               $ mode: real_time_dsp_ola<br/>
               $ status: source_code_generated
             </div>
           </div>
        </div>
      </div>

       <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(232, 121, 176, 0.1); border-radius: 99px; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: rgba(232, 121, 176, 0.3); }
      `}</style>
    </div>
  );
}
